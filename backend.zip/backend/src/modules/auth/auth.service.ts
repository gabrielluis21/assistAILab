import bcrypt from 'bcrypt';
import { prisma } from '../../core/database/prisma.js';
import { RegisterInput, LoginInput } from './auth.schema.js';
import { ConflictError, UnauthorizedError, ForbiddenError } from '../../core/utils/errors.js';

const SALT_ROUNDS = 12;

export class AuthService {
  async register(input: RegisterInput) {
    const passwordHash = await hashPassword(input.password);

    return prisma.$transaction(async (tx) => {
      const customer = await tx.customer.create({
        data: {
          name: input.name,
          email: input.email,
        },
      });

      const user = await tx.user.create({
        data: {
          name: input.name,
          email: input.email,
          passwordHash,
          role: 'CUSTOMER',
          customerId: customer.id,
        },
      });

      return user;
    });
  }

  async validateCredentials(input: LoginInput) {
    const user = await prisma.user.findUnique({ where: { email: input.email } });
    if (!user) throw new UnauthorizedError('Invalid credentials');

    const valid = await bcrypt.compare(input.password, user.passwordHash);
    if (!valid) throw new UnauthorizedError('Invalid credentials');

    return { id: user.id, name: user.name, email: user.email, role: user.role, customerId: user.customerId };
  }
}
function hashPassword(password: string) {
  throw new Error('Function not implemented.');
}

